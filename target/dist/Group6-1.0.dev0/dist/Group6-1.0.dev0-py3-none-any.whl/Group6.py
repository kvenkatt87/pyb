import sys
def Group6(out):
    out.write("Assignment Pending\n")